1. Open payload.ps1 in a text editor and replace the contents with your intended script.
2. Open Powershell
3. Type "./EncryptPayload.ps1" without quotes and hit Enter
4. Create a passphrase
5. Open the newly generated "encrypted_payload.txt" in a text editor and copy it's contents.
5. Open secure_loader.ps1 in a text editor and past in the encrypted payload hash where it says: "<REPLACE_THIS_WITH_YOUR_NEW_BASE64_PAYLOAD>"
6. Copy the contents of secure_loader.ps1 into a GitHub Gist or some other host.