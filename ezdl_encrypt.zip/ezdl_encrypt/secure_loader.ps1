# Prompt for passphrase
$SecurePassword = Read-Host "Enter passphrase" -AsSecureString
$PasswordString = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
    [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePassword)
)

try {
    # Derive AES-256 key (must match encryption logic)
    $Key = [System.Text.Encoding]::UTF8.GetBytes($PasswordString.PadRight(32, 'X'))[0..31]

    # Encrypted payload (Base64, IV + Ciphertext)
    $enc = @'
<REPLACE_THIS_WITH_YOUR_NEW_BASE64_PAYLOAD>
'@ -replace "`r`n", ""

    $Bytes = [Convert]::FromBase64String($enc)

    # Extract IV (first 16 bytes) and ciphertext
    $IV = $Bytes[0..15]
    $CipherText = $Bytes[16..($Bytes.Length - 1)]

    # Decrypt
    $Aes = [System.Security.Cryptography.Aes]::Create()
    $Aes.Mode = "CBC"
    $Aes.Padding = "PKCS7"
    $Aes.Key = $Key
    $Aes.IV = $IV
    $Decryptor = $Aes.CreateDecryptor()
    $PlainBytes = $Decryptor.TransformFinalBlock($CipherText, 0, $CipherText.Length)
    $PlainText = [System.Text.Encoding]::UTF8.GetString($PlainBytes)

    Invoke-Expression $PlainText
}
catch {
    Write-Host "❌ Decryption failed or invalid passphrase." -ForegroundColor Red
}
