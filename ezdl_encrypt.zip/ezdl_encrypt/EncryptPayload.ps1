# Prompt for the passphrase
$SecurePassword = Read-Host "Enter passphrase" -AsSecureString
$PasswordString = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto(
    [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePassword)
)

# Derive a 32-byte AES key by padding the string (must match decryption)
$Key = [System.Text.Encoding]::UTF8.GetBytes($PasswordString.PadRight(32, 'X'))[0..31]

# Initialize AES and generate random IV
$Aes = [System.Security.Cryptography.Aes]::Create()
$Aes.Mode = "CBC"
$Aes.Padding = "PKCS7"
$Aes.Key = $Key
$Aes.GenerateIV()
$IV = $Aes.IV

# Load the plaintext script you want to encrypt
$PlainText = Get-Content ".\payload.ps1" -Raw
$PlainBytes = [System.Text.Encoding]::UTF8.GetBytes($PlainText)

# Encrypt the script
$Encryptor = $Aes.CreateEncryptor()
$CipherBytes = $Encryptor.TransformFinalBlock($PlainBytes, 0, $PlainBytes.Length)

# Combine IV and ciphertext, then encode to Base64
$FinalBytes = $IV + $CipherBytes
$Base64Payload = [Convert]::ToBase64String($FinalBytes)

# Output to file
$Base64Payload | Set-Content "encrypted_payload.txt" -Encoding ASCII
Write-Host "✅ Encrypted and saved to encrypted_payload.txt" -ForegroundColor Green
